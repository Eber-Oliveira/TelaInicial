import view.TelaInicial;

public class TelaPrograma {
    public static void main(String[] args) {
        TelaInicial telaInicial = new TelaInicial();
        telaInicial.setVisible(true);
    }
}
